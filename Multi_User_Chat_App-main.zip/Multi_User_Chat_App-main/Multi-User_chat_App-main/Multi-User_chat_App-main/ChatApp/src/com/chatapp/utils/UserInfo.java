package com.chatapp.utils;

public class UserInfo {
	private UserInfo() {}  //sp that no one can make object
	public static String USER_NAME;
}
